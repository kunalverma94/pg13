import {combineReducers} from 'redux'
import { containerReducer } from "./Reducers/ContainerReducer";

export const rootreducer=combineReducers({containerReducer});