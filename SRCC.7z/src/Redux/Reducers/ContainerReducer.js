import { ACTS } from "../Types/types";

const initialstate = {
    level: 2,
    plist: [],
    dlist: [],
    alist: [],
};
export function containerReducer(is = initialstate, action) {
    if (action.type === ACTS.INIT) {
        return { ...action.payload };
    }

    if (action.type === ACTS.FLIP) {
        let _plist = [...is.plist];
        let _dlist = [...is.dlist];
        const wasflipped = _plist[action.payload].class === '';
        _plist[action.payload].class = wasflipped ? 'flip' : '';
        if (_dlist.length >= 3 && wasflipped) {
            is.dlist.forEach(p => {
                _plist[p].class = '';
            })
            _dlist = []
        }
        if (wasflipped) {
            _dlist.push(action.payload);
        }
        else {
            _dlist = _dlist.filter(u => u !== action.payload);
        }
        return { ...is, plist: _plist, dlist: _dlist };
    }
    if (action.type === ACTS.REMOVE) {
        let _plist = [...is.plist];
        is.dlist.forEach(p => {
            _plist[p].class = 'hide';

        })
        return { ...is, plist: _plist, dlist: [] };
    }
    return is;
}