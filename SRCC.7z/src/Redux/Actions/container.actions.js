import { ACTS } from "../Types/types";
export const rurl = "https://raw.githubusercontent.com/kunalverma94/pokemon/master/evolutions/[CODE].json";

export const fetchPlist = (level) => (dispatch) => {
    let rl = [];
    let y = 1;
    if (sessionStorage.getItem("b") != null) {
        y = Math.floor(Math.random() * 151);
    }
    for (let i = y; i < level + y; i++) {
        rl.push(fetch(rurl.replace('[CODE]', i)).then(t => t.json()).then(u => GetEvolutionsAnswers(u.chain)));
    }
    Promise.all(rl).then(k => (dispatch(
        {
            type: ACTS.INIT,
            payload: {
                alist: k.map(u => u.sort().join("-")),
                plist: [].concat.apply([], k).map(e => ({
                    id: e,
                    class: '',
                })).shuffle(),
                result: k,
                level: level,
                dlist: []
            }
        })));
}
export const flipAction = (i) => (dispatch) => {
    dispatch({ type: ACTS.FLIP, payload: i })
}
export const HideAction = (i) => (dispatch) => {
    dispatch({ type: ACTS.REMOVE })
}
function GetEvolutionsAnswers(u, rval = []) {
    if (u.evolves_to === undefined || u.evolves_to.length === 0) {
        rval.push(u.species.url.split("/").reverse()[1]);
    } else {
        rval.push(u.species.url.split("/").reverse()[1]);
        GetEvolutionsAnswers(u.evolves_to[0], rval);
    }
    return rval;
}

// function GetEvolutions(u,rval=[]) {
//     if (u.evolves_to==undefined||u.evolves_to.length===0) {
//     rval.push({...u.species,id:u.species.url.split("/").reverse()[1]});
//     } else {
//         rval.push({...u.species,id:u.species.url.split("/").reverse()[1]});
//         GetEvolutions(u.evolves_to[0],rval);
//     }
//     return rval;
// }

