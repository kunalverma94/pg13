export const ACTS =
{
    INIT: 'INIT',
    FLIP: 'FLIP',
    REMOVE: 'HIDE'
}
