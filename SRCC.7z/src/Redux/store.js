import { createStore, applyMiddleware } from 'redux'
import { rootreducer } from './rootreducer';
import thunk from 'redux-thunk'
// import { logs } from './mware/logger';
export const store = createStore(rootreducer, {}, applyMiddleware(thunk));

