export function logs({ getState, dispatch }) {

    return function (next) {
        return function (action) {
            next(action);
        }
    }
}

export function api({ getState, dispatch }) {
    return function (next) {
        return function (action) {
            if (action.request) {
                fetch(action.request.url).then(t => t.json()).then(j => {
                    action.request.success(j);
                    action.data = j;
                });
            }
            next(action);
        }
    }
}

