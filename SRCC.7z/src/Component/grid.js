import React, { Component } from 'react'
import { connect } from 'react-redux'
import Pokeball from './Pokeball';
import { fetchPlist, flipAction, HideAction } from "../Redux/Actions/container.actions";
class Grid extends Component {
    checkmate(balls, flipped, answers) {
        setTimeout(() => {
            if (flipped.length > 0) {
                let keylements = flipped.map(u => balls[u]);
                let _key = keylements.map(i => i.id).sort().join('-')
                if (answers.findIndex(g => g === _key) > -1) {
                    this.props.HideAction();
                }
            }
        }, 450);
    }
    componentDidUpdate() {
        let c = this.props.balls.filter(u => u.class === 'hide').length;
        if (c === this.props.balls.length) {
            setTimeout(() => {
                this.props.fetchPlist(this.props.level + 1);
            }, 2000);
        }
    }
    componentDidMount() {
        this.props.fetchPlist(this.props.level + 1);
    }
    render() {
        const { balls, flipped, answers } = this.props;
        this.checkmate(balls, flipped, answers);
        return (
            <div className="xelf">
                {balls.map((t, i, a) => {
                    return <Pokeball key={i} passdata={t} events={
                        { click: this.props.flipAction.bind(this, i) }
                    } ></Pokeball>
                })}
            </div>
        )
    }
}

const mapStateToProps = (state) => {
    return { balls: state.containerReducer.plist, flipped: state.containerReducer.dlist, answers: state.containerReducer.alist, level: state.containerReducer.level }
};

export default connect(mapStateToProps, { fetchPlist, flipAction, HideAction })(Grid)
