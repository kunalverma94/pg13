import React, { Component } from 'react'
import { connect } from 'react-redux'
import './container.css';
import Scoreboard from './scoreboard';
import Grid from './grid';
class Container extends Component {
  render() {
    return (
      <React.Fragment>
        <Grid></Grid>
        <Scoreboard></Scoreboard>
      </React.Fragment>
    )
  }
}
const mapStateToProps = (state, ownProps) => {
  return {

  }
}
export default connect(mapStateToProps, {})(Container)
