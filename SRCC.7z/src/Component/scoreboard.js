import React, { Component } from 'react'
import { connect } from 'react-redux'
import { fetchPlist } from "../Redux/Actions/container.actions";
import './scoreboard.css'
class Scoreboard extends Component {
    next() {
        this.props.fetchPlist(this.props.level + 1);
    }
    render() {
        return (
            <div className="pannel"  >
                <div className="progress left " >
                    <div className="block">
                        <div className="blocklabel" >Left</div>
                        <div>{this.props.remain}</div>
                    </div>
                    <div className="block">
                        <div className="blocklabel" >Total</div>
                        <div>{this.props.total}</div>
                    </div>
                </div>
                <div className="progress right " >
                    <div className="block level" onClick={(e)=>{
                    if (!sessionStorage.getItem('b')) {
                        sessionStorage.setItem('b','1');
                        e.currentTarget.classList.add('hard');
                    }
                    else{
                        sessionStorage.removeItem('b');
                        e.currentTarget.classList.remove('hard');

                    }
                    
                }}>
                        <div className="blocklabel" >Level</div>
                        <div>{this.props.level}</div>
                    </div>
                    <div className="block next" onClick={this.next.bind(this)}>
                        <div className="blocklabel" >&nbsp;</div>
                        <div className="btn-txt center">Next</div>
                    </div>
                </div>
            </div>
        )
    }
}

const mapStateToProps = (state) => {
    let r = {
        level: state.containerReducer.level,
        total: state.containerReducer.plist.length,
        remain: state.containerReducer.plist.filter(i => i.class === 'hide').length
    }
    r.remain = r.total - r.remain;
    return r
}

const mapDispatchToProps = {
    fetchPlist
}

export default connect(mapStateToProps, mapDispatchToProps)(Scoreboard)
