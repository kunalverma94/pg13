import React, { Component } from 'react'
import { connect } from 'react-redux'
import './Pokeball.css';
const iurl = 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/[U].png';
class Pokeball extends Component {
  render() {
    return (<div className={"inner " + this.props.passdata.class} onClick={() => {
      this.props.events.click()
    }}>
      <div   >
        <div className="front" style={{ background: "url(" + iurl.replace("[U]", this.props.passdata.id) + ")" }} >
          {this.props.passdata.id}
        </div>
        <div className="back" style={{ background: "url(" + iurl.replace("[U]", this.props.passdata.id) + ")" }}>
        </div>
      </div>
    </div>);
  }
}
const mapStateToProps = (state, pr) => ({
  state, pr
});
export default connect(mapStateToProps, {})(Pokeball);
