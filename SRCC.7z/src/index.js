import React from  'react';
import ReactDOM from 'react-dom';
import App from './Component/app';
import './poly';
import './styles.css'
ReactDOM.render( <App></App> ,document.getElementById('root'))